package com.example.proyectoicfesfirebase

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.proyectoicfesfirebase.databinding.ActivityCategoriasMainBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase

class CategoriasMainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityCategoriasMainBinding

    private lateinit var auth: FirebaseAuth


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCategoriasMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        auth = Firebase.auth

        binding.btnCerrarSesion.setOnClickListener{
            cerrarSesion()
        }
        binding.btnAdicionarCategoria.setOnClickListener{
            val intent = Intent(this, RegistroCategorias::class.java)
            this.startActivity(intent)
        }
    }

    private fun cerrarSesion() {
        auth.signOut()
        val intent = Intent(this, MainActivity::class.java)
        this.startActivity(intent)
    }
}