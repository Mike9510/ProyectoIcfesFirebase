package com.example.proyectoicfesfirebase.model

data class Categoria (
        val id:String,
        val nombreCategoria: String
        )
